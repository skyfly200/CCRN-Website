<?php 
	$pagename = "About";
	// import html head section
	require '../head.php'; 
	// start html body section
	echo "<body>";
	// inport header
	require '../header.php'; 
?>
	<div class="container-fluid">	
		<div class="row">
			<h2>Dowload Content Submissions</h2>
		</div>
	</div>
    </div><!-- /.container-fluid -->

		
<?php
	require '../footer.php'; 
?>