<?php
// database credentials
	$servername = "localhost";
	$username = "user";
	$password = "password";
	$dbname = "ccrn test";
?>